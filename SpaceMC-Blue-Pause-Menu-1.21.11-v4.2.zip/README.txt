SpaceMC Blue Pause Menu v4.2 - Java 1.21.11

V4.2 fixes:
- Nudged the top SpaceMC header slightly to the right so the whole menu reads more centered in-game.
- Moved the Discord/store footer to the very bottom so mod-added pause buttons no longer sit behind it.
- Made the footer compact so Give Feedback, Report Bugs, Options, Player Reporting, Mods, and disconnect/leave controls stay readable.
- Slightly reduced the SpaceMC header size for cleaner spacing.
- Updated the Discord link to discord.gg/spacenetwork.
- Kept the V4 blue/cyan button styling and hover/disabled states.

Footer:
discord.gg/spacenetwork
store.spacemc.net

Server setup:
Host this ZIP at a direct HTTPS URL, then set resource-pack=<URL> and require-resource-pack=true in server.properties.
Set resource-pack-sha1 to the SHA-1 in SpaceMC-Blue-Pause-Menu-1.21.11-v4.2.sha1.txt.
