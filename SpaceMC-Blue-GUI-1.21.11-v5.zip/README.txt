SpaceMC Blue GUI v5 - Java 1.21.11

Includes:
- SpaceMC blue/cyan custom pause menu from v4.4.
- New SpaceMC survival inventory + 2x2 crafting GUI.
- Dark navy sci-fi panel, cyan glowing slot frames, player preview frame, and SpaceMC wordmark.
- No planet behind the SpaceMC inventory wordmark.
- Discord footer remains discord.gg/spacenetwork.

Vanilla-compatible layout:
- Slot positions and crafting positions are unchanged, so items still line up correctly.
- This is a visual resource-pack change only; it does not move or change inventory functionality.

Server setup:
Upload this ZIP to a direct HTTPS URL and set resource-pack=<URL> and require-resource-pack=true.
Use the SHA-1 provided alongside this ZIP for resource-pack-sha1.
