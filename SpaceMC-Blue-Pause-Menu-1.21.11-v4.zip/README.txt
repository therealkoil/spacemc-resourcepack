SpaceMC Blue Pause Menu v4 - Java 1.21.11

V4 changes:
- New blue/cyan sci-fi pause-menu styling inspired by the approved SpaceMC V4 mockup.
- Upgraded glowing SpaceMC header art and cosmic accents.
- New dark navy + electric cyan button sprites, including hover and disabled states.
- Escape-menu text now uses: Back among the stars! / Until my next orbit.
- Restored the vanilla-style center options: Advancements, Statistics, Give Feedback, Report Bugs, Options..., Player Reporting.
- Discord/store footer retained and restyled below the menu.
- New V4 pack icon.

Footer:
discord.gg/spacemc
store.spacemc.net

Server setup:
Host this ZIP at a direct HTTPS URL, then set resource-pack=<URL> and require-resource-pack=true in server.properties.
Set resource-pack-sha1 to the SHA-1 in SpaceMC-Blue-Pause-Menu-1.21.11-v4.sha1.txt.
