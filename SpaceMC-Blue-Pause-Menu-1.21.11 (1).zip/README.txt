SpaceMC Blue Pause Menu - Java 1.21.11

This pack replaces vanilla menu button sprites with a dark-navy/electric-blue theme and uses a custom font glyph for the SpaceMC pause-menu header/footer.
Footer text: discord.gg/spacenetwork | store.spacemc.net

Server setup: host this ZIP at a direct HTTPS URL, then set resource-pack=<URL> and require-resource-pack=true in server.properties.
Use the SHA-1 provided alongside the ZIP for resource-pack-sha1.
