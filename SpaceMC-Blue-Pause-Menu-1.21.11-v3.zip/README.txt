SpaceMC Blue Pause Menu v2 - Java 1.21.11

Changes in v2:
- Removed the SpaceMC logo/header graphic from the pause menu.
- Moved the Discord/store footer below the Leave SpaceMC button.
- Kept the dark-navy/electric-blue vanilla button reskin.

Footer text:
discord.gg/spacenetwork
store.spacemc.net

Server setup: host this ZIP at a direct HTTPS URL, then set resource-pack=<URL> and require-resource-pack=true in server.properties.
Use the SHA-1 provided for resource-pack-sha1.
