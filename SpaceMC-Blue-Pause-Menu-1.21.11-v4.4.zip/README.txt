SpaceMC Blue Pause Menu v4.4 - Java 1.21.11

V4.4 centering fix:
- Rebuilt the pause-menu overlay positioning instead of manually nudging the image.
- The large SpaceMC overlay now has zero effective layout width, so it no longer pushes Minecraft's native pause-menu layout off-center.
- Cropped the overlay canvas to its real visual width and centered the logo/footer geometry.
- Discord remains discord.gg/spacenetwork.
- Store remains store.spacemc.net.
- Keeps the blue/cyan buttons, hover state, and V4.1 spacing.

Footer:
discord.gg/spacenetwork
store.spacemc.net

Server setup:
Host this ZIP at a direct HTTPS URL, then set resource-pack=<URL> and require-resource-pack=true in server.properties.
Use the SHA-1 supplied with the v4.4 ZIP for resource-pack-sha1.
